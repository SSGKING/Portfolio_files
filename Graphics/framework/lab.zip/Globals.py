

class GlobalVariables:
    def __init__(self):
        #put globals here...
        self.keys = set()
        self.red = 0
        self.yellow = 1
        self.playerX = 0.5
        self.playerY = 0.5
        self.stateMachine = set()


        
        

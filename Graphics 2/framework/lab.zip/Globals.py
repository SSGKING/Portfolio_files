class GlobalVars:
    def __init__(self):
        pass
        

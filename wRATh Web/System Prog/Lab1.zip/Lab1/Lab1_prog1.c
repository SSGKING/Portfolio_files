#include<stdio.h>
main()
{
    printf("Alex Neill\n");
    printf("\"Hello World!\"");
}

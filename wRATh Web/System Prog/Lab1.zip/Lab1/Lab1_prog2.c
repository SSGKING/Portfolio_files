
int printf(const char *format, ...);

main()
{
    printf("Alex Neill\n");
    printf("\"Hello World!\"");
}

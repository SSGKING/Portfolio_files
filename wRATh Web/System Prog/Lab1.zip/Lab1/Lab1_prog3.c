//Name:
//Class:    Section:
//Assignment:
//Only #defines are allowed here in this program.
//You should fill them in.
#define begin {
#define end }
#define writeln(x) printf(x), printf("\n")
#define write(x) printf(x)


main()
begin
  write("First ");
  write("Line");
  writeln(" ");
  writeln("Alex Neill");
  writeln("'Hello World!'");
end

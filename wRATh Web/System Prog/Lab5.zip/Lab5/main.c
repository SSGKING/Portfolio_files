//name: Alex Neill
//class ETEC 2110.01
//assignment: Lab 5 main.c
int main()
